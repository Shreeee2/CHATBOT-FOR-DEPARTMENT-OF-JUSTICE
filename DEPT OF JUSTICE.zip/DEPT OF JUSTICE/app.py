import streamlit as st
import requests
from bs4 import BeautifulSoup
import google.generativeai as genai
from io import BytesIO
import fitz  # PyMuPDF
from docx import Document
from dotenv import load_dotenv
import os
from common import urls_keywords  # Import the urls_keywords list
from fuzzywuzzy import fuzz
from textblob import TextBlob  # For spelling correction
from itertools import permutations  # For keyword reordering
import speech_recognition as sr
from gtts import gTTS
import pygame

# Initialize pygame for playing sound
pygame.init()

# Load environment variables
load_dotenv()

# Configure generative AI
genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))

# Define the predefined FAQ questions
faq_questions = [
    {"question": "What is eFiling?", "url": "https://doj.gov.in/efiling/"},
    {"question": "What is the Vision and Mission?", "url": "https://doj.gov.in/about-department/vision-and-mission/"},
    {"question": "Tell about the Department Of Justice", "url": "https://doj.gov.in/"},
    {"question": "What is the procedure for e-Payment?", "url": "https://doj.gov.in/e-payments/"},
    {"question": "How can I access live streaming of court cases?", "url": "https://doj.gov.in/live-streaming-of-court-cases/"}
]

# Map questions to URLs from urls_keywords
def map_questions_to_urls():
    """
    Maps the predefined FAQs to their corresponding URLs using the urls_keywords list from common.py.
    """
    for faq in faq_questions:
        for item in urls_keywords:
            if any(fuzz.token_set_ratio(faq["question"].lower(), keyword.lower()) > 80 for keyword in item["keywords"]):
                faq["url"] = item["url"]
                break

# Call this function to map URLs when the script runs
map_questions_to_urls()

def correct_spelling(text):
    """
    Correct spelling mistakes in the provided text using TextBlob.
    """
    blob = TextBlob(text)
    corrected_text = str(blob.correct())
    return corrected_text

def get_matching_url(query, threshold=60):
    """
    Return a URL based on the provided query using keywords from common.py with fuzzy matching.
    """
    query_lower = query.lower()
    best_match_url = None
    highest_score = 0
    
    # Correct spelling in the query
    corrected_query = correct_spelling(query_lower)
    
    for item in urls_keywords:
        url = item["url"]
        keywords = item["keywords"]
        
        for keyword in keywords:
            # Convert the keyword to lowercase for case-insensitive matching
            keyword_lower = keyword.lower()
            
            # Fuzzy matching with different types of scores
            token_score = fuzz.token_set_ratio(corrected_query, keyword_lower)
            partial_score = fuzz.partial_ratio(corrected_query, keyword_lower)
            sort_score = fuzz.token_sort_ratio(corrected_query, keyword_lower)
            
            # Take the highest score
            max_score = max(token_score, partial_score, sort_score)
            
            if max_score > highest_score:
                highest_score = max_score
                best_match_url = url

        # Check permutations of keywords to handle keyword reordering
        for perm in permutations(keywords):
            perm_str = ' '.join(perm).lower()
            perm_score = fuzz.token_set_ratio(corrected_query, perm_str)
            if perm_score > highest_score:
                highest_score = perm_score
                best_match_url = url

    # Debugging output
    print(f"Query: {corrected_query}")
    print(f"Best Match URL: {best_match_url}")
    print(f"Highest Score: {highest_score}")

    # Check if the best match exceeds the threshold
    if highest_score >= threshold:
        return best_match_url
    return None

def get_gemini_response(prompt):
    """
    Generate a response using Gemini AI (Generative AI Model).
    """
    model = genai.GenerativeModel('gemini-pro')
    response = model.generate_content(prompt)
    return response.text

def extract_text_from_url(url):
    """
    Function to extract text from a URL and remove any specific unwanted content.
    """
    text = ""
    try:
        response = requests.get(url)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        paragraphs = soup.find_all(['p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'])
        text = '\n'.join([para.get_text() for para in paragraphs]) + "\n\n"
        
        # Remove specific unwanted content
        unwanted_text = "Content Owned by DEPARTMENT OF JUSTICE, Ministry of Law and Justice, GOI"
        text = text.replace(unwanted_text, "").strip()

    except Exception as e:
        text = f"An error occurred while fetching content from {url}: {str(e)}\n\n"
    return text

def extract_text_from_pdf(pdf_file):
    """
    Function to extract text from a PDF file.
    """
    text = ""
    try:
        with fitz.open(stream=pdf_file.read(), filetype="pdf") as doc:
            for page in doc:
                text += page.get_text()
    except Exception as e:
        text = f"An error occurred while reading the PDF: {str(e)}"
    return text

def extract_text_from_docx(docx_file):
    """
    Function to extract text from a DOCX file.
    """
    text = ""
    try:
        doc = Document(docx_file)
        for para in doc.paragraphs:
            text += para.text + "\n"
    except Exception as e:
        text = f"An error occurred while reading the DOCX file: {str(e)}"
    return text

def ask_question_about_content(content_text, question):
    """
    Function to ask a question based on extracted text.
    """
    question_prompt = f"The following text is from the website:\n\n{content_text}\n\nAnswer the following question based on the text: {question}"
    answer = get_gemini_response(question_prompt)
    return answer

def process_content(user_prompt):
    """
    Function to handle content from either a URL, PDF, DOCX, or other formats.
    """
    url = get_matching_url(user_prompt)

    if url:
        if url.endswith(".pdf"):  # Check if the URL is for a PDF file
            try:
                response = requests.get(url)
                response.raise_for_status()
                pdf_content = BytesIO(response.content)
                content_text = extract_text_from_pdf(pdf_content)
            except Exception as e:
                st.error(f"Error fetching PDF content: {e}")
                return None
        elif url.endswith(".docx"):  # Check if the URL is for a DOCX file
            try:
                response = requests.get(url)
                response.raise_for_status()
                docx_content = BytesIO(response.content)
                content_text = extract_text_from_docx(docx_content)
            except Exception as e:
                st.error(f"Error fetching DOCX content: {e}")
                return None
        else:
            # Treat it as a regular webpage or PHP file
            content_text = extract_text_from_url(url)
        
        return content_text
    else:
        st.error("No matching URL found.")
        return None

# Function to recognize speech and convert it to text
def recognize_speech():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        st.write("Listening...")
        audio = recognizer.listen(source)
        try:
            text = recognizer.recognize_google(audio)
            st.write(f"Recognized speech: {text}")
            return text
        except sr.UnknownValueError:
            st.write("Sorry, I could not understand the audio.")
            return None
        except sr.RequestError:
            st.write("Could not request results from Google Speech Recognition service.")
            return None

# Function to find the most relevant FAQ based on the user's query
def find_relevant_faq(query):
    best_match = None
    highest_ratio = 0

    for faq in faq_questions:
        ratio = fuzz.ratio(faq['question'].lower(), query.lower())
        if ratio > highest_ratio:
            highest_ratio = ratio
            best_match = faq

    return best_match

# Flag to enable or disable text-to-speech functionality
ENABLE_SPEECH = False

# Function to convert text to speech and play it
def text_to_speech(text):
    if ENABLE_SPEECH:
        tts = gTTS(text=text, lang='en')
        audio_file = BytesIO()
        tts.write_to_fp(audio_file)
        audio_file.seek(0)
        pygame.mixer.music.load(audio_file)
        pygame.mixer.music.play()

# Streamlit app
st.set_page_config(page_title="DoJ Website Chatbot", page_icon="🗨️")

# Inject custom CSS for background image
st.markdown(
    r'''
    <style>
    .main {
        background-image: url('https://wallpaperaccess.com/full/1353541.jpg');
        background-size: cover;
        background-position: center;
    }
    .css-1f5f3s2 {
        background: rgba(255, 255, 255, 0.8);
    }
    </style>
    ''',
    unsafe_allow_html=True
)

st.title("Department of Justice Website Chatbot")
st.markdown("---")

# Automated greeting
st.markdown("## Hi, how may I help you today?")

# Use expander for FAQ buttons
with st.expander("Frequently Asked Questions"):
    for idx, faq in enumerate(faq_questions):
        if st.button(faq["question"], key=f"faq_{idx}"):
            user_prompt = faq["question"]
            selected_url = faq["url"]  # Get the corresponding URL for the selected question
            if selected_url:
                content_text = extract_text_from_url(selected_url)
                st.subheader("Answer")
                st.markdown(content_text)
                st.markdown(f"[Here is the link for further information]({selected_url})")
            else:
                st.error("No URL found for this question.")

# Text-based query input
user_prompt = st.text_input("Or enter your query:")

if st.button("Submit"):
    if user_prompt:
        # Process the content based on URL or file
        content_text = process_content(user_prompt)
        
        if content_text:
            # Ask question based on the content extracted
            answer = ask_question_about_content(content_text, user_prompt)
            st.subheader("Answer")
            st.markdown(answer)
        else:
            st.error("Failed to extract content.")
    else:
        st.error("Please enter a valid query.")

# Voice-activated FAQ chatbot
if st.button("Ask a question (Voice)"):
    user_query = recognize_speech()
    if user_query:
        # Find the most relevant FAQ
        relevant_faq = find_relevant_faq(user_query)
        if relevant_faq:
            st.write(f"Question: {relevant_faq['question']}")
            # Extract and display the answer from the URL
            answer = extract_text_from_url(relevant_faq['url'])
            st.write(f"Answer: {answer}")

            # Provide vocal support (conditionally enabled)
            if ENABLE_SPEECH:
                text_to_speech(answer)
        else:
            st.write("No relevant FAQ found.")
            if ENABLE_SPEECH:
                text_to_speech("No relevant FAQ found.")
    else:
        st.write("Please ask a valid query.")
        if ENABLE_SPEECH:
            text_to_speech("Please ask a valid query.")


